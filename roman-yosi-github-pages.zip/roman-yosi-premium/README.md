# Roman Yosi — Official Website

Website statis premium untuk GitHub Pages.

## Cara memasang
1. Masuk ke https://github.com dan login.
2. Klik **New repository**.
3. Beri nama repository `roman-yosi` (atau nama lain), pilih **Public**, lalu klik **Create repository**.
4. Klik **Add file → Upload files**.
5. Unggah `index.html` dari paket ini, lalu klik **Commit changes**.
6. Buka **Settings → Pages**.
7. Pada **Build and deployment**, pilih **Deploy from a branch**.
8. Pilih branch **main** dan folder **/(root)**, lalu klik **Save**.
9. Tunggu beberapa menit. Alamat website biasanya:
   `https://USERNAME.github.io/roman-yosi/`
   Ganti `USERNAME` dengan nama akun GitHub Anda.

## Yang perlu diperiksa sebelum publikasi
- Pastikan foto profil pada URL di `index.html` memang foto yang ingin ditampilkan.
- Periksa tautan Instagram, TikTok, YouTube, dan Spotify.
- Pastikan daftar judul lagu dan keterangan biografi sudah akurat.
- Untuk memakai domain sendiri, atur domain di Settings → Pages setelah situs berhasil terbit.

## Mengubah isi
Buka `index.html` di GitHub, klik ikon pensil, ubah teks/tautan yang diperlukan, lalu klik **Commit changes**.
